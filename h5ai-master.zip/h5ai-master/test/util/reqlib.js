const reqlib = x => require(`../../src/_h5ai/public/js/lib/${x}`);

module.exports = reqlib;
